package com.harindra.tvlauncher

import android.app.Activity
import android.app.role.RoleManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AlertDialog

object LauncherHomeManager {

    private val KNOWN_STOCK_LAUNCHERS = listOf(
        "com.google.android.apps.tv.launcherx",
        "com.google.android.tvlauncher",
        "com.mitv.tvhome",
        "com.tcl.cyberui",
        "com.sony.dtv.homelauncher",
        "com.amazon.tv.launcher",
        "com.hisense.tv.launcher"
    )

    fun isDefaultHomeLauncher(context: Context): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ri?.activityInfo?.packageName == context.packageName
        } catch (_: Throwable) { false }
    }

    fun getCurrentDefaultHomePackage(context: Context): String {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val ri = context.packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
            ri?.activityInfo?.packageName ?: "Unknown"
        } catch (_: Throwable) { "Unknown" }
    }

    fun detectStockLauncherPackage(context: Context): String {
        // 1. Dynamically find EVERY other HOME launcher installed on this TV (e.g., HikeenLauncher!)
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            val matches = context.packageManager.queryIntentActivities(homeIntent, 0)
            for (ri in matches) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg != context.packageName && !pkg.contains("settings", true)) {
                    return pkg
                }
            }
        } catch (_: Throwable) { }
        // 2. Fallback to known list
        return KNOWN_STOCK_LAUNCHERS.firstOrNull { pkg ->
            try { context.packageManager.getPackageInfo(pkg, 0); true } catch (_: Throwable) { false }
        } ?: "com.google.android.tvlauncher"
    }

    fun triggerHomeRoleOrChooser(activity: Activity) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val rm = activity.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
                    activity.startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_HOME))
                    return
                }
            }
            activity.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (_: Throwable) {
            try {
                val selector = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_HOME)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                activity.startActivity(Intent.createChooser(selector, "Select UltraTV Pro -> Always"))
            } catch (_: Throwable) {
                openSystemSettingsSafe(activity, Settings.ACTION_SETTINGS)
            }
        }
    }

    fun openRestoreOriginalLauncher(activity: Activity) {
        Toast.makeText(activity, "Choose your original TV Home app in Default Home Settings", Toast.LENGTH_LONG).show()
        try {
            activity.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            openSystemSettingsSafe(activity, Settings.ACTION_SETTINGS)
        }
    }

    fun showSetupWizard(activity: Activity, installedApps: List<AppItem>, onLaunchApp: (AppItem) -> Unit) {
        val isDef = isDefaultHomeLauncher(activity)
        val currentPkg = getCurrentDefaultHomePackage(activity)
        val stockPkg = detectStockLauncherPackage(activity)
        val statusLine = if (isDef) {
            "Status: ACTIVE — UltraTV Pro is your current Default Home Launcher!"
        } else {
            "Status: NOT DEFAULT (Current Home: $currentPkg)"
        }

        AlertDialog.Builder(activity, R.style.GtvDialogTheme)
            .setTitle("Default Home Launcher Setup Wizard")
            .setMessage(
                "$statusLine\n\n" +
                "1. Tap 'Set UltraTV Home' to open Android's official Home / RoleManager chooser and pick UltraTV Pro -> Always.\n" +
                "2. Once selected, pressing the TV Remote HOME button returns instantly to UltraTV Pro.\n" +
                "3. Need to switch back? Tap 'Restore Original' anytime. (UltraTV Pro never auto-disables system apps.)\n" +
                "4. On locked Android TVs where the manufacturer overrides Home, tap 'ADB TV Guide' for optional user-initiated instructions ($stockPkg)."
            )
            .setPositiveButton("Set UltraTV Home") { _, _ -> triggerHomeRoleOrChooser(activity) }
            .setNeutralButton("Restore Original") { _, _ -> openRestoreOriginalLauncher(activity) }
            .setNegativeButton("ADB TV Guide") { _, _ -> showAdbTvGuide(activity, installedApps, onLaunchApp) }
            .show()
    }

    fun showAdbTvGuide(activity: Activity, installedApps: List<AppItem>, onLaunchApp: (AppItem) -> Unit) {
        val stockPkg = detectStockLauncherPackage(activity)
        val cmd = "pm disable-user --user 0 $stockPkg"
        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        cm?.setPrimaryClip(ClipData.newPlainText("ADB Stock Launcher Command", cmd))

        val adbApps = listOf("com.cybercat.adbappcontrol.tv", "com.cgutman.androidremotedebugger", "dev.vodik7.tvquickactions", "com.htc.atvtools")
        val installedAdb = installedApps.firstOrNull { app ->
            app.packageName in adbApps || app.label.contains("adb", true) || app.label.contains("atvtools", true)
        }

        AlertDialog.Builder(activity, R.style.GtvDialogTheme)
            .setTitle("Optional ADB TV Helper (User-Initiated)")
            .setMessage(
                "Detected Stock Launcher: $stockPkg\n" +
                "Copied Command: $cmd\n\n" +
                "Note: Android does not allow apps to disable system launchers automatically. If your TV manufacturer locks the Home button, you can optionally use ADB TV / AtvTools manually after enabling Debugging in Developer Options."
            )
            .setPositiveButton(if (installedAdb != null) "Open ${installedAdb.label}" else "Developer Options") { _, _ ->
                if (installedAdb != null) onLaunchApp(installedAdb)
                else openSystemSettingsSafe(activity, Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)
            }
            .setNeutralButton("Home Settings") { _, _ -> triggerHomeRoleOrChooser(activity) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun openSystemSettingsSafe(activity: Activity, action: String) {
        try {
            activity.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { activity.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) {}
        }
    }
}
