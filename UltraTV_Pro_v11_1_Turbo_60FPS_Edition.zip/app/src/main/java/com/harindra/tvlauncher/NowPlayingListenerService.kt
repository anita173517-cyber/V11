package com.harindra.tvlauncher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NowPlayingListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val pkg = sbn?.packageName ?: return
        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (title.isBlank() || title.length < 2) return

        val lower = pkg.lowercase()
        val p = PrefsManager(applicationContext)
        when {
            lower.contains("moviebox") || lower.contains("mbox") || lower.contains("onstream") || lower.contains("filmbox") -> {
                p.saveDetectedMovieBoxMedia(title, pkg)
            }
            lower.contains("youtube") || lower.contains("smarttube") -> {
                p.saveDetectedYouTubeMedia(title, text.ifBlank { "YouTube" })
            }
            lower == "com.harindra.iptvpro" || lower.contains("iptv") || lower.contains("tivimate") || lower.contains("xciptv") -> {
                p.saveDetectedIptvMedia(title, pkg)
            }
        }
    }
}
