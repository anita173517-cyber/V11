package com.harindra.tvlauncher

import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView

object Animation4D {

    private val fastDecel = DecelerateInterpolator(1.4f)

    fun applyTierFocus(view: View, hasFocus: Boolean, tier: PerformanceTier, enableAnim: Boolean) {
        view.animate().cancel()
        if (!enableAnim || tier.animDurationMs == 0L) {
            val s = if (hasFocus) tier.focusScale else 1.0f
            view.scaleX = s
            view.scaleY = s
            return
        }
        val target = if (hasFocus) tier.focusScale else 1.0f
        view.animate()
            .scaleX(target)
            .scaleY(target)
            .setDuration(tier.animDurationMs)
            .setInterpolator(fastDecel)
            .start()
    }

    fun apply4dFocus(view: View, hasFocus: Boolean, ultraLite: Boolean, scaleTarget: Float = 1.07f) {
        view.animate().cancel()
        val target = if (hasFocus) scaleTarget else 1.0f
        if (ultraLite) {
            view.scaleX = target
            view.scaleY = target
        } else {
            view.animate()
                .scaleX(target)
                .scaleY(target)
                .setDuration(90L)
                .setInterpolator(fastDecel)
                .start()
        }
    }

    fun animateKenBurnsHero(imageView: ImageView, enableKenBurns: Boolean) {
        imageView.animate().cancel()
        imageView.alpha = 1.0f
        imageView.scaleX = 1.0f
        imageView.scaleY = 1.0f
        if (enableKenBurns) {
            imageView.animate()
                .scaleX(1.05f)
                .scaleY(1.05f)
                .setDuration(8000L)
                .start()
        }
    }

    fun animateTabEntrance(view: View, ultraLite: Boolean) {
        // Instant tab switch — zero lag!
        view.alpha = 1f
        view.translationY = 0f
    }
}
