package com.harindra.tvlauncher

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Xml
import android.widget.Toast
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

object YouTubeRepository {

    // Top verified YouTube official RSS feeds (Zero API key required, works directly on Android TV!)
    private val FEED_CHANNELS = listOf(
        Triple("UCq-Fj5jknLsUf-MWSy4_brA", "T-Series", "Music"),
        Triple("UCZSNzBgFub_WWil6TOTYwAg", "Netflix India", "Movies"),
        Triple("UC4zWG9LccdWGUlF77LZ8toA", "Prime Video India", "Series"),
        Triple("UC56gTxNs4f9xZ7Pa2i5xNzg", "Sony Music India", "Music"),
        Triple("UCt2JXdjxaj1F92zI4qH3Mmw", "ICC Cricket", "Sports"),
        Triple("UCvC4D8onUfXzvjTOM-dBfEA", "Marvel Entertainment", "Movies"),
        Triple("UCOhHO2ICt0ti9KAh-QHvttQ", "Technical Guruji", "Tech")
    )

    // Instant curated starter catalog with real YouTube 4K video IDs (always ready even offline!)
    fun getInstantCuratedVideos(): List<YouTubeVideo> = listOf(
        YouTubeVideo("COv52Qyctws", "Jawan Official Action Trailer 4K", "Red Chillies Entertainment", "Movies", "4K HDR", R.drawable.hero_action_4k),
        YouTubeVideo("vqu4z34wENw", "Pathaan Official Blockbuster Trailer", "YRF", "Movies", "4K", R.drawable.hero_action_4k),
        YouTubeVideo("f_vbAtFSEc0", "RRR Official Trailer — Action Epic", "DVV Entertainment", "Movies", "4K", R.drawable.hero_fantasy_4k),
        YouTubeVideo("d9MyW72ELq0", "Avatar: The Way of Water Official 4K", "20th Century Studios", "Movies", "4K 60fps", R.drawable.hero_scifi_4k),
        YouTubeVideo("vhwr4vc_GY0", "Gadar 2 Official Action Trailer", "Zee Studios", "Movies", "HD", R.drawable.hero_action_4k),
        YouTubeVideo("LXb3EKWsInQ", "COSTA RICA IN 4K 60fps HDR Ultra HD", "Jacob + Katie Schwarz", "Trending", "4K HDR", R.drawable.hero_scifi_4k),
        YouTubeVideo("aqz-KE-bpKQ", "Big Buck Bunny 4K 60fps Animated", "Blender Foundation", "Series", "4K 60fps", R.drawable.hero_kids_4k),
        YouTubeVideo("Bey4XXJAqS8", "Ultra HD 4K World Cinema Showcase", "4K Relaxation", "Trending", "4K", R.drawable.hero_sports_4k)
    )

    fun fetchLiveTrendingVideos(): List<YouTubeVideo> {
        val fetched = mutableListOf<YouTubeVideo>()
        for ((channelId, label, cat) in FEED_CHANNELS) {
            try {
                val url = URL("https://www.youtube.com/feeds/videos.xml?channel_id=$channelId")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 4000
                    readTimeout = 5000
                    setRequestProperty("User-Agent", "Mozilla/5.0 (Android TV)")
                }
                if (conn.responseCode in 200..299) {
                    conn.inputStream.use { stream ->
                        fetched.addAll(parseAtomFeed(stream, label, cat, limit = 3))
                    }
                }
                conn.disconnect()
            } catch (_: Throwable) {
                // Skip unreachable feed gracefully
            }
        }
        return if (fetched.isNotEmpty()) {
            (fetched.shuffled().take(18) + getInstantCuratedVideos()).distinctBy { it.videoId }
        } else {
            getInstantCuratedVideos()
        }
    }

    private fun parseAtomFeed(stream: InputStream, defaultChannel: String, category: String, limit: Int): List<YouTubeVideo> {
        val out = mutableListOf<YouTubeVideo>()
        val parser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(stream, "UTF-8")

        var inEntry = false
        var videoId = ""
        var title = ""
        var author = defaultChannel
        var event = parser.eventType

        while (event != XmlPullParser.END_DOCUMENT && out.size < limit) {
            when (event) {
                XmlPullParser.START_TAG -> {
                    val tag = parser.name ?: ""
                    if (tag == "entry") {
                        inEntry = true
                        videoId = ""
                        title = ""
                        author = defaultChannel
                    } else if (inEntry) {
                        when (tag) {
                            "yt:videoId" -> videoId = parser.nextText().trim()
                            "title" -> title = parser.nextText().trim()
                            "name" -> author = parser.nextText().trim().ifBlank { defaultChannel }
                        }
                    }
                }
                XmlPullParser.END_TAG -> {
                    if (parser.name == "entry" && inEntry) {
                        inEntry = false
                        if (videoId.isNotBlank() && title.isNotBlank()) {
                            val fallback = when (category) {
                                "Sports" -> R.drawable.hero_sports_4k
                                "Series" -> R.drawable.hero_fantasy_4k
                                "Tech" -> R.drawable.hero_scifi_4k
                                else -> R.drawable.hero_action_4k
                            }
                            out.add(
                                YouTubeVideo(
                                    videoId = videoId,
                                    title = title,
                                    channelName = author,
                                    category = category,
                                    badge = "HD",
                                    fallbackResId = fallback
                                )
                            )
                        }
                    }
                }
            }
            event = parser.next()
        }
        return out
    }

    fun openYouTubeVideo(context: Context, prefs: PrefsManager, video: YouTubeVideo) {
        // Persist immediately so it appears in Continue Watching even after TV power-off!
        prefs.recordYouTubeWatch(video)

        val watchUrl = "https://www.youtube.com/watch?v=${video.videoId}"
        val ytPackages = listOf(
            "com.google.android.youtube.tv",
            "com.liskovsoft.smarttubetv.beta",
            "com.teamsmart.videomanager.tv",
            "com.google.android.youtube"
        )

        for (pkg in ytPackages) {
            if (isPackageInstalled(context, pkg)) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(watchUrl)).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(intent)
                    return
                } catch (_: Throwable) { }
            }
        }

        // Fallback to vnd.youtube or generic VIEW
        val vndIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:${video.videoId}")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(vndIntent)
            return
        } catch (_: Throwable) { }

        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(watchUrl)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            Toast.makeText(context, "YouTube app not found on TV", Toast.LENGTH_SHORT).show()
        }
    }

    fun openYouTubeSearch(context: Context, query: String) {
        val encoded = Uri.encode(query)
        val url = "https://www.youtube.com/results?search_query=$encoded"
        val ytPackages = listOf(
            "com.google.android.youtube.tv",
            "com.liskovsoft.smarttubetv.beta",
            "com.google.android.youtube"
        )
        for (pkg in ytPackages) {
            if (isPackageInstalled(context, pkg)) {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage(pkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    context.startActivity(i)
                    return
                } catch (_: Throwable) { }
            }
        }
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            Toast.makeText(context, "Could not open YouTube", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isPackageInstalled(context: Context, pkg: String): Boolean {
        return try {
            context.packageManager.getPackageInfo(pkg, 0)
            true
        } catch (_: Throwable) {
            false
        }
    }
}
